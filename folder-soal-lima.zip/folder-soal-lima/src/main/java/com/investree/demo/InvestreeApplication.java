package com.investree.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InvestreeApplication {

    public static void main(String[] args) {
        SpringApplication.run(InvestreeApplication.class, args);
    }

}
